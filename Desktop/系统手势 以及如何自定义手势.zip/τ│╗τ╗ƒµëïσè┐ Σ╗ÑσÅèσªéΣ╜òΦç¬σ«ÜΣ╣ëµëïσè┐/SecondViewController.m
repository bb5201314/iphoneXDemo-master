//
//  SecondViewController.m
//  系统手势 以及如何自定义手势
//
//  Created by 赵小波 on 2017/10/31.
//  Copyright © 2017年 赵小波. All rights reserved.
//

#import "SecondViewController.h"
#import "CustomerGestureRecognizer.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor  whiteColor];
   
    CustomerGestureRecognizer *customerGesture=[[CustomerGestureRecognizer  alloc]initWithTarget:self action:@selector(customerTap:)];
    [self.view addGestureRecognizer:customerGesture];
}
-(void)customerTap:(CustomerGestureRecognizer *)tap{


    [self.navigationController popViewControllerAnimated:YES];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
