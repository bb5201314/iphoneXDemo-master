//
//  CustomerGestureRecognizer.h
//  系统手势 以及如何自定义手势
//
//  Created by 赵小波 on 2017/10/31.
//  Copyright © 2017年 赵小波. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomerGestureRecognizer : UIGestureRecognizer

//需要几根手指操作
@property(nonatomic,assign)NSInteger nummberOfTouchesRequired;

//需要几次点击
@property(nonatomic,assign)NSInteger numberOfTapsRequired;
//哪一边
@property(readwrite,nonatomic,assign)UIRectEdge customerEdge;
//默认是UIRectEdgeAll  

@end
