//
//  AppDelegate.h
//  系统手势 以及如何自定义手势
//
//  Created by 赵小波 on 2017/10/31.
//  Copyright © 2017年 赵小波. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

