//
//  ViewController.m
//  系统手势 以及如何自定义手势
//
//  Created by 赵小波 on 2017/10/31.
//  Copyright © 2017年 赵小波. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"


@interface ViewController ()
/*
 系统封装好的手势
 
 UITapGestureRecognizer(轻击)
 UILongPressGestureRecognizer(长按)
 ​UISwipeGestureRecognizer(轻扫)
 UIPanGestureRecognizer(拖动)
 UIPinchGestureRecognizer(捏合)
 UIRotationGestureRecognizer(旋转)
 UIScreenEdgePanGestureRecognizer(屏幕边缘手势继承于pan手势）
 
 
 
 */
@property(nonatomic,strong)UIView *View2;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
//    UITapGestureRecognizer  *tap1=[[ UITapGestureRecognizer  alloc]initWithTarget:self action:@selector(tapAction:)];
//    [self.view addGestureRecognizer:tap1];
//    //设置 敲击的有效次数
//    tap1.numberOfTapsRequired=2;
//    //设置敲击的手指个数
//    tap1.numberOfTouchesRequired=1;
//    self.view.userInteractionEnabled=YES;
    
//    UILongPressGestureRecognizer *pressTap=[[UILongPressGestureRecognizer  alloc]initWithTarget:self action:@selector(pressAction:)];
//    [self.view addGestureRecognizer:pressTap];
    self.view.userInteractionEnabled=YES;
//    pressTap.minimumPressDuration=0.5;
//    pressTap.allowableMovement=20.0;
    
//
//    UISwipeGestureRecognizer *swipeTap=[[UISwipeGestureRecognizer  alloc]initWithTarget:self action:@selector(swipeAction:)];
//    [self.view addGestureRecognizer:swipeTap];
//
    
//    UIPanGestureRecognizer *pinVc=[[UIPanGestureRecognizer  alloc]initWithTarget:self action:@selector(panVcAction:)];
//    [self.view addGestureRecognizer:pinVc];
    
    UIView *view2=[[UIView  alloc]initWithFrame:CGRectMake(100, 100,200, 200)];
    view2.backgroundColor=[UIColor greenColor];
    [self.view addSubview:view2];
    self.View2=view2;
    view2.userInteractionEnabled=YES;

    
//    UIPinchGestureRecognizer *pinTap=[[UIPinchGestureRecognizer  alloc]initWithTarget:self action:@selector(pinAction:)];
//    [view2 addGestureRecognizer:pinTap];
    
//    UIRotationGestureRecognizer *rotationTap=[[UIRotationGestureRecognizer  alloc]initWithTarget:self action:@selector(rotationAction:)];
//    [self.View2 addGestureRecognizer:rotationTap];
    
        UITapGestureRecognizer  *tap1=[[ UITapGestureRecognizer  alloc]initWithTarget:self action:@selector(tapAction:)];
        [self.view addGestureRecognizer:tap1];
}

-(void)rotationAction:(UIRotationGestureRecognizer *)tap{
    
    //旋转要两个手指 
    if (tap.state==UIGestureRecognizerStateChanged)
    {
        self.View2.transform=CGAffineTransformMakeRotation(M_PI_4);
    }
    if(tap.state==UIGestureRecognizerStateEnded)
    {
        [UIView animateWithDuration:1 animations:^{
            self.View2.transform=CGAffineTransformIdentity;//取消形变
        }];
    }
    
  
}
-(void)pinAction:(UIPinchGestureRecognizer *)tap{
    
    NSLog(@"捏合手势");
    if (tap.state==UIGestureRecognizerStateChanged) {
        
        self.View2.transform=CGAffineTransformMakeScale(tap.scale,tap.scale);
    }
    if (tap.state==UIGestureRecognizerStateEnded) {
        
        [UIView animateWithDuration:1.0 animations:^{
           
            self.View2.transform=CGAffineTransformIdentity;;
        }];
    }
    
}
-(void)panVcAction:(UIPanGestureRecognizer  *)tap{
    
    NSLog(@"拖动手势");
    if (tap.state==UIGestureRecognizerStateChanged) {
        
        CGPoint p=[tap  translationInView:self.view];
        [tap  setTranslation:CGPointZero inView:self.view];
    }

    
}
-(void)tapAction:(UITapGestureRecognizer *)tap{
    
    NSLog(@"点击手势");
    SecondViewController *secondVc=[[SecondViewController  alloc]init];
    
    [self.navigationController pushViewController:secondVc animated:YES];
}

-(void)pressAction:(UILongPressGestureRecognizer *)tap{
    
    NSLog(@"长按手势");
}
-(void)swipeAction:(UISwipeGestureRecognizer *)tap{
    
    NSLog(@"轻扫手势");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
