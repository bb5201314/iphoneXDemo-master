//
//  CustomerGestureRecognizer.m
//  系统手势 以及如何自定义手势
//
//  Created by 赵小波 on 2017/10/31.
//  Copyright © 2017年 赵小波. All rights reserved.
//

#import "CustomerGestureRecognizer.h"
//#import <UIKit/UIGestureRecognizer.h>
#import <UIKit/UIGestureRecognizerSubclass.h>

@interface CustomerGestureRecognizer ()

@property(nonatomic,assign)BOOL isCorrected;

@end

@implementation CustomerGestureRecognizer

//在开始触摸里面判断手势对不对 几根手指 几次点击 哪一边  此方法左右：作为手势识别器

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [super touchesBegan:touches withEvent:event];
    
    NSArray *allTouches=[touches  allObjects];
    //0.判断手指的tapCount碰撞次数  是否在move里面给出移动初始点
    for (UITouch   *touch in  allTouches) {
        
        //每个点的手指个数
        
        if (touch.tapCount !=(self.numberOfTapsRequired)) {
            
            //不符合直接return
            return;
        }
        
    }
    //判断需要几根手指
    if (allTouches.count!=self.nummberOfTouchesRequired) {
        
        //忽略不正确的手指
        for (UITouch  *tou  in  allTouches) {
            
            [self  ignoreTouch:tou forEvent:event];
        }
        
        return;
    }
    
    //手指个数满足条件的情况下  判断手指的位置满足条件不
     //用临时变量topM等接收 防止屏幕旋转出现
    CGFloat topM=self.view.bounds.size.height*0.25;//满足点小于topM
    CGFloat butM=self.view.bounds.size.height*0.75;//满足点要大于butM
    CGFloat leftM=self.view.bounds.size.width*0.25;//满足点要小于leftM
    CGFloat rightM=self.view.bounds.size.width*0.75;//满足点要大于rightM
    if (topM >= 100) {
        topM = 100;
        butM = self.view.bounds.size.height - 100;
    }
    if (leftM >= 100) {
        leftM = 100;
        rightM = self.view.bounds.size.width - 100;
    }
    // 判断手指位置是否满足条件
    for (UITouch * tou in allTouches) {
        if (!self.view) {
            return;
        }//貌似能触发began就肯定有view
        CGPoint touchP = [tou locationInView:self.view];//手指位置
        if (self.customerEdge == UIRectEdgeNone) {
            return;//UIRectEdgeNone什么也不做
        }
        if (self.customerEdge == UIRectEdgeTop) {
            if (touchP.y > topM) {
                [self ignoreTouch:tou forEvent:event];
                return;
            }
        }
        if (self.customerEdge == UIRectEdgeBottom) {
            if (touchP.y < butM) {
                [self ignoreTouch:tou forEvent:event];
                return;
            }
        }
        if (self.customerEdge == UIRectEdgeLeft) {
            if (touchP.x > leftM) {
                [self ignoreTouch:tou forEvent:event];
                return;
            }
        }
        if (self.customerEdge == UIRectEdgeRight) {
            if (touchP.x < rightM) {
                [self ignoreTouch:tou forEvent:event];
                return;
            }
        }
        if (self.customerEdge == UIRectEdgeAll) {
            if (touchP.y > topM && touchP.y < butM && touchP.x > leftM && touchP.x < rightM) {
                [self ignoreTouch:tou forEvent:event];
                return;
            }
        }
    }
    self.isCorrected = YES;//识别正确，当前状态UIGestureRecognizerStatePossible
    
  
}
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    [super touchesMoved:touches  withEvent:event];
    
    if (!self.isCorrected) {
        //不满足began的情况 直接返回
        return;
    }
    //识别正确 移动既是began
    self.state = UIGestureRecognizerStateBegan;//自动内部会自动改变状态为move
    
   
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesEnded:touches withEvent:event];
    if(self.isCorrected){
        self.state = UIGestureRecognizerStateEnded;
        self.state = UIGestureRecognizerStateRecognized;
        [self reset];
    }
}

#pragma mark - 重写方法
- (void)reset{
    [super reset];
    self.isCorrected = NO;
}
//没有end状态 又识别到其他手势的时候  多了手指出来
- (BOOL)canPreventGestureRecognizer:(UIGestureRecognizer *)preventedGestureRecognizer{
    BOOL res = [super canPreventGestureRecognizer:preventedGestureRecognizer];
    self.state = UIGestureRecognizerStateCancelled;
    [self reset];
    return res;
}

//第一次识别 touchBegan之后调用
- (BOOL)shouldRequireFailureOfGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    BOOL res = [super shouldRequireFailureOfGestureRecognizer:otherGestureRecognizer];
    return res;
}

#pragma mark - 默认值设置
//重写init 设置默认值
- (instancetype)init{
    if(self = [super init]){
        self.customerEdge = UIRectEdgeAll;
        self.nummberOfTouchesRequired = 1;
        self.numberOfTapsRequired = 0;
        self.isCorrected = NO;
    }
    return self;
}

- (instancetype)initWithTarget:(id)target action:(SEL)action{
    if (self = [super initWithTarget:target action:action]) {
        self.customerEdge = UIRectEdgeAll;
        self.numberOfTapsRequired = 0;
        self.nummberOfTouchesRequired = 1;
        self.isCorrected = NO;
    }
    return self;
}


@end
